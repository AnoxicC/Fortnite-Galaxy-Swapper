## Galaxy Swapper v2

Revamp your Fortnite experience with our skin swapper designed for the latest version of Fortnite. This repository contains the source code for Galaxy Swapper v2.


## What is Galaxy Swapper v2?

Galaxy Swapper v2 is a free Fortnite skin changer built in WPF that allows you to modify your game files to replace a cosmetic you own with a cosmetic you desire, all with ease. We have also developed a simple and user-friendly user-interface for your convenience.

## Endpoints used in our application

* [Fortnite-Api](https://dash.fortnite-api.com)


